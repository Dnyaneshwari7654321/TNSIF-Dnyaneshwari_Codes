package dao;

import models.Beneficiary;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BeneficiaryDAO {

    // Add Beneficiary
    public void addBeneficiary(Beneficiary beneficiary) {
        String query = "INSERT INTO Beneficiary (customerID, name, accountNumber, bankDetails) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, beneficiary.getCustomerID());
            stmt.setString(2, beneficiary.getName());
            stmt.setLong(3, beneficiary.getAccountNumber());
            stmt.setString(4, beneficiary.getBankDetails());
            stmt.executeUpdate();

            System.out.println("Beneficiary added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get All Beneficiaries of a Customer
    public List<Beneficiary> getBeneficiariesByCustomerId(int customerID) {
        List<Beneficiary> beneficiaries = new ArrayList<>();
        String query = "SELECT * FROM Beneficiary WHERE customerID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                beneficiaries.add(new Beneficiary(
                        rs.getInt("beneficiaryID"),
                        rs.getInt("customerID"),
                        rs.getString("name"),
                        rs.getLong("accountNumber"),
                        rs.getString("bankDetails")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return beneficiaries;
    }
}
