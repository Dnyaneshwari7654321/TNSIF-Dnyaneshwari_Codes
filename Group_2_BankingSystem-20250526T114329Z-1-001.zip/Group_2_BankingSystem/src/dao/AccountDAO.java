package dao;

import models.Account;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO {
    // Add Account
    public void addAccount(Account account) {
        String query = "INSERT INTO Account (customerID, type, balance) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, account.getCustomerID());
            stmt.setString(2, account.getType());
            stmt.setDouble(3, account.getBalance());
            stmt.executeUpdate();
            System.out.println("Account added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get All Accounts of a Customer
    public List<Account> getAccountsByCustomerId(int customerID) {
        List<Account> accounts = new ArrayList<>();
        String query = "SELECT * FROM Account WHERE customerID = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, customerID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                accounts.add(new Account(
                        rs.getInt("accountID"),
                        rs.getInt("customerID"),
                        rs.getString("type"),
                        rs.getDouble("balance")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return accounts;
    }
}
