package dao;

public class TransactionAccountDAO {
}
