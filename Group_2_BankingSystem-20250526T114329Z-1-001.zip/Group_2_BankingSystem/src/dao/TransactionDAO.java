package dao;

import models.Transaction;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    // Deposit or Withdraw Money
    public boolean addTransaction(int accountID, String type, double amount) {
        String insertQuery = "INSERT INTO Transaction (accountID, type, amount) VALUES (?, ?, ?)";
        String updateBalanceQuery = type.equalsIgnoreCase("Deposit")
                ? "UPDATE Account SET balance = balance + ? WHERE accountID = ?"
                : "UPDATE Account SET balance = balance - ? WHERE accountID = ? AND balance >= ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
             PreparedStatement updateStmt = conn.prepareStatement(updateBalanceQuery)) {

            conn.setAutoCommit(false); // Start transaction

            // Insert transaction record
            insertStmt.setInt(1, accountID);
            insertStmt.setString(2, type);
            insertStmt.setDouble(3, amount);
            insertStmt.executeUpdate();

            // Update account balance
            updateStmt.setDouble(1, amount);
            updateStmt.setInt(2, accountID);
            if (type.equalsIgnoreCase("Withdraw")) {
                updateStmt.setDouble(3, amount);
            }

            int rowsUpdated = updateStmt.executeUpdate();
            if (type.equalsIgnoreCase("Withdraw") && rowsUpdated == 0) {
                conn.rollback(); // Insufficient funds, rollback transaction
                return false;
            }

            conn.commit(); // Commit transaction
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Fetch Transaction History
    public List<Transaction> getTransactionsByAccountId(int accountID) {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM Transaction WHERE accountID = ? ORDER BY timestamp DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, accountID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                transactions.add(new Transaction(
                        rs.getInt("transactionID"),
                        rs.getInt("accountID"),
                        rs.getString("type"),
                        rs.getDouble("amount"),
                        rs.getTimestamp("timestamp").toLocalDateTime()
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }

    public boolean transferFunds(int senderAccountID, int receiverAccountID, double amount) {
        String checkBalanceQuery = "SELECT balance FROM Account WHERE accountID = ?";
        String withdrawQuery = "UPDATE Account SET balance = balance - ? WHERE accountID = ? AND balance >= ?";
        String depositQuery = "UPDATE Account SET balance = balance + ? WHERE accountID = ?";
        String insertTransactionQuery = "INSERT INTO Transaction (accountID, type, amount) VALUES (?, 'Transfer', ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement checkBalanceStmt = conn.prepareStatement(checkBalanceQuery);
             PreparedStatement withdrawStmt = conn.prepareStatement(withdrawQuery);
             PreparedStatement depositStmt = conn.prepareStatement(depositQuery);
             PreparedStatement senderTransactionStmt = conn.prepareStatement(insertTransactionQuery);
             PreparedStatement receiverTransactionStmt = conn.prepareStatement(insertTransactionQuery)) {

            conn.setAutoCommit(false); // Start transaction

            // **Step 1: Check Sender's Balance**
            checkBalanceStmt.setInt(1, senderAccountID);
            ResultSet rs = checkBalanceStmt.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    System.out.println("Insufficient Balance!");
                    conn.rollback();
                    return false;
                }
            } else {
                System.out.println("Sender Account Not Found!");
                conn.rollback();
                return false;
            }

            // **Step 2: Withdraw from Sender**
            withdrawStmt.setDouble(1, amount);
            withdrawStmt.setInt(2, senderAccountID);
            withdrawStmt.setDouble(3, amount);
            int withdrawUpdated = withdrawStmt.executeUpdate();

            if (withdrawUpdated == 0) {
                System.out.println("Failed to Withdraw: Insufficient Funds!");
                conn.rollback();
                return false;
            }

            // **Step 3: Deposit to Receiver**
            depositStmt.setDouble(1, amount);
            depositStmt.setInt(2, receiverAccountID);
            int depositUpdated = depositStmt.executeUpdate();

            if (depositUpdated == 0) {
                System.out.println("Receiver Account Not Found!");
                conn.rollback();
                return false;
            }

            // **Step 4: Record Transaction for Sender**
            senderTransactionStmt.setInt(1, senderAccountID);
            senderTransactionStmt.setDouble(2, -amount); // Negative amount for sender
            senderTransactionStmt.executeUpdate();

            // **Step 5: Record Transaction for Receiver**
            receiverTransactionStmt.setInt(1, receiverAccountID);
            receiverTransactionStmt.setDouble(2, amount);
            receiverTransactionStmt.executeUpdate();

            conn.commit(); // Commit transaction
            System.out.println("Transfer Successful!");
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
