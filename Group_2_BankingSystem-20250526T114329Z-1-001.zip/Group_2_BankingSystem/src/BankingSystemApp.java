public class BankingSystemApp {
    public static void main(String[] args) {
        new ui.MainMenu();
    }
}
