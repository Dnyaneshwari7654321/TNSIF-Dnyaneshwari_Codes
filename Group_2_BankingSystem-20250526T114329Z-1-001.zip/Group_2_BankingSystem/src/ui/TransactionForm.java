package ui;

import dao.TransactionDAO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransactionForm extends JFrame {
    private JTextField senderAccountIdField, receiverAccountIdField, amountField;
    private TransactionDAO transactionDAO;

    // Default Constructor (Allows Manual Entry)
    public TransactionForm() {
        this(0); // Calls the second constructor with no pre-filled receiver
    }

    // Constructor with Pre-filled Receiver (When Coming from Beneficiary List)
    public TransactionForm(long beneficiaryAccountNumber) {
        transactionDAO = new TransactionDAO();

        setTitle("Fund Transfer");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Sender Account ID:"));
        senderAccountIdField = new JTextField();
        add(senderAccountIdField);

        add(new JLabel("Receiver Account ID:"));
        receiverAccountIdField = new JTextField(beneficiaryAccountNumber > 0 ? String.valueOf(beneficiaryAccountNumber) : "");
        receiverAccountIdField.setEditable(beneficiaryAccountNumber > 0); // Lock field if coming from beneficiary
        add(receiverAccountIdField);

        add(new JLabel("Amount:"));
        amountField = new JTextField();
        add(amountField);

        JButton transferButton = new JButton("Transfer Funds");
        transferButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int senderAccountID = Integer.parseInt(senderAccountIdField.getText());
                int receiverAccountID = Integer.parseInt(receiverAccountIdField.getText());
                double amount = Double.parseDouble(amountField.getText());

                boolean success = transactionDAO.transferFunds(senderAccountID, receiverAccountID, amount);

                if (success) {
                    JOptionPane.showMessageDialog(null, "Transfer Successful!");
                } else {
                    JOptionPane.showMessageDialog(null, "Transfer Failed! Check Balance.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(transferButton);
        setVisible(true);
    }
}

