package ui;

import dao.BeneficiaryDAO;
import models.Beneficiary;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableCellEditor;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewBeneficiaries extends JFrame {
    private JTextField customerIdField;
    private JTable table;
    private DefaultTableModel model;
    private BeneficiaryDAO beneficiaryDAO;

    public ViewBeneficiaries() {
        beneficiaryDAO = new BeneficiaryDAO();

        setTitle("View Beneficiaries");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel for input
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 3));

        panel.add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        panel.add(customerIdField);

        JButton searchButton = new JButton("View Beneficiaries");
        panel.add(searchButton);

        // Table for displaying beneficiaries
        model = new DefaultTableModel(new String[]{"ID", "Name", "Account Number", "Bank", "Transfer"}, 0);
        table = new JTable(model);
        table.getColumn("Transfer").setCellRenderer(new ButtonRenderer());
        table.getColumn("Transfer").setCellEditor(new ButtonEditor(new JCheckBox()));

        JScrollPane scrollPane = new JScrollPane(table);

        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadBeneficiaries();
            }
        });

        setVisible(true);
    }

    private void loadBeneficiaries() {
        model.setRowCount(0);
        int customerId = Integer.parseInt(customerIdField.getText());
        List<Beneficiary> beneficiaries = beneficiaryDAO.getBeneficiariesByCustomerId(customerId);

        if (beneficiaries.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No beneficiaries found.");
        } else {
            for (Beneficiary beneficiary : beneficiaries) {
                model.addRow(new Object[]{
                        beneficiary.getBeneficiaryID(),
                        beneficiary.getName(),
                        beneficiary.getAccountNumber(),
                        beneficiary.getBankDetails(),
                        "Transfer" // Button text instead of JButton
                });
            }
        }
    }

    // Opens the Transaction Form with Pre-Filled Receiver Account
    private void openTransactionForm(long beneficiaryAccountNumber) {
        new TransactionForm(beneficiaryAccountNumber);
    }

    // Custom Button Renderer
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setText("Transfer");
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    // Custom Button Editor (Handles Click Events)
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private long beneficiaryAccountNumber;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton("Transfer");
            button.addActionListener(e -> openTransactionForm(beneficiaryAccountNumber));
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            beneficiaryAccountNumber = Long.parseLong(table.getValueAt(row, 2).toString());
            return button;
        }
    }
}
