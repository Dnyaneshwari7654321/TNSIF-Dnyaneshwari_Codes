package ui;

import dao.AccountDAO;
import models.Account;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewAccounts extends JFrame {
    private JTextField customerIdField;
    private JTextArea resultArea;
    private AccountDAO accountDAO;

    public ViewAccounts() {
        accountDAO = new AccountDAO();

        setTitle("View Customer Accounts");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));

        panel.add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        panel.add(customerIdField);

        JButton searchButton = new JButton("View Accounts");
        panel.add(searchButton);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int customerId = Integer.parseInt(customerIdField.getText());
                List<Account> accounts = accountDAO.getAccountsByCustomerId(customerId);

                resultArea.setText("");
                if (accounts.isEmpty()) {
                    resultArea.append("No accounts found for this customer.\n");
                } else {
                    for (Account account : accounts) {
                        resultArea.append(account.toString() + "\n");
                    }
                }
            }
        });

        setVisible(true);
    }
}
