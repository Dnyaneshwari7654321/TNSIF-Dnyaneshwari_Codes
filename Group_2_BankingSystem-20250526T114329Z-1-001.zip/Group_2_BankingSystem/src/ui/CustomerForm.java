package ui;

import dao.CustomerDAO;
import models.Customer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CustomerForm extends JFrame {
    private JTextField nameField, addressField, contactField;
    private CustomerDAO customerDAO;

    public CustomerForm() {
        customerDAO = new CustomerDAO();

        setTitle("Add Customer");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Address:"));
        addressField = new JTextField();
        add(addressField);

        add(new JLabel("Contact:"));
        contactField = new JTextField();
        add(contactField);

        JButton addButton = new JButton("Add Customer");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String address = addressField.getText();
                String contact = contactField.getText();

                Customer customer = new Customer(0, name, address, contact);
                customerDAO.addCustomer(customer);

                JOptionPane.showMessageDialog(null, "Customer Added Successfully!");
            }
        });

        add(addButton);
        setVisible(true);
    }
}
