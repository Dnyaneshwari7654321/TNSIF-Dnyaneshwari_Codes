package ui;

import dao.AccountDAO;
import models.Account;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AccountForm extends JFrame {
    private JTextField customerIdField, balanceField;
    private JComboBox<String> accountTypeBox;
    private AccountDAO accountDAO;

    public AccountForm() {
        accountDAO = new AccountDAO();

        setTitle("Create New Account");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        add(customerIdField);

        add(new JLabel("Account Type:"));
        String[] accountTypes = {"Saving", "Current"};
        accountTypeBox = new JComboBox<>(accountTypes);
        add(accountTypeBox);

        add(new JLabel("Initial Balance:"));
        balanceField = new JTextField();
        add(balanceField);

        JButton addButton = new JButton("Create Account");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int customerId = Integer.parseInt(customerIdField.getText());
                String type = (String) accountTypeBox.getSelectedItem();
                double balance = Double.parseDouble(balanceField.getText());

                Account account = new Account(0, customerId, type, balance);
                accountDAO.addAccount(account);

                JOptionPane.showMessageDialog(null, "Account Created Successfully!");
            }
        });

        add(addButton);
        setVisible(true);
    }
}
