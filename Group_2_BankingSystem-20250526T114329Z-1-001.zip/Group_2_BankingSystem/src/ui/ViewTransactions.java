package ui;

import dao.TransactionDAO;
import models.Transaction;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewTransactions extends JFrame {
    private JTextField accountIdField;
    private JTextArea resultArea;
    private TransactionDAO transactionDAO;

    public ViewTransactions() {
        transactionDAO = new TransactionDAO();

        setTitle("View Transactions");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));

        panel.add(new JLabel("Account ID:"));
        accountIdField = new JTextField();
        panel.add(accountIdField);

        JButton searchButton = new JButton("View Transactions");
        panel.add(searchButton);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int accountID = Integer.parseInt(accountIdField.getText());
                List<Transaction> transactions = transactionDAO.getTransactionsByAccountId(accountID);

                resultArea.setText("");
                if (transactions.isEmpty()) {
                    resultArea.append("No transactions found for this account.\n");
                } else {
                    for (Transaction transaction : transactions) {
                        resultArea.append(transaction.toString() + "\n");
                    }
                }
            }
        });

        setVisible(true);
    }
}
