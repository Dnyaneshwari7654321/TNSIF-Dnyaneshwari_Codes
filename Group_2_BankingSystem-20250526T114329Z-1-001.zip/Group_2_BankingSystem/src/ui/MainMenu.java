package ui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("Banking System");
        setSize(300, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JButton addCustomerButton = new JButton("Add Customer");
        JButton createAccountButton = new JButton("Create Account");
        JButton viewAccountsButton = new JButton("View Accounts");
        JButton createTransactionButton = new JButton("Create Transaction");
        JButton viewTransactionsButton = new JButton("View Transaction");
        JButton addBeneficiaryButton = new JButton("Add Beneficiary");
        JButton viewBeneficiariesButton = new JButton("View Beneficiaries");
        JButton exitButton = new JButton("Exit");

        addCustomerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new CustomerForm();
            }
        });

        createAccountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AccountForm();
            }
        });

        viewAccountsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewAccounts();
            }
        });

        createTransactionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new TransactionForm();
            }
        });

        viewTransactionsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewTransactions();
            }
        });

        addBeneficiaryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new BeneficiaryForm();
            }
        });

        viewBeneficiariesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewBeneficiaries();
            }
        });


        exitButton.addActionListener(e -> System.exit(0));

        add(addCustomerButton);
        add(createAccountButton);
        add(viewAccountsButton);
        add(createTransactionButton);
        add(viewTransactionsButton);
        add(addBeneficiaryButton);
        add(viewBeneficiariesButton);
        add(exitButton);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MainMenu();
    }
}
