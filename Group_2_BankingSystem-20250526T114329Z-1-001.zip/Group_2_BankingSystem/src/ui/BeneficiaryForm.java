package ui;

import dao.BeneficiaryDAO;
import models.Beneficiary;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BeneficiaryForm extends JFrame {
    private JTextField customerIdField, nameField, accountNumberField, bankDetailsField;
    private BeneficiaryDAO beneficiaryDAO;

    public BeneficiaryForm() {
        beneficiaryDAO = new BeneficiaryDAO();

        setTitle("Add Beneficiary");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        add(customerIdField);

        add(new JLabel("Beneficiary Name:"));
        nameField = new JTextField();
        add(nameField);

        add(new JLabel("Beneficiary Account Number:"));
        accountNumberField = new JTextField();
        add(accountNumberField);

        add(new JLabel("Bank Details:"));
        bankDetailsField = new JTextField();
        add(bankDetailsField);

        JButton addButton = new JButton("Add Beneficiary");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int customerId = Integer.parseInt(customerIdField.getText());
                String name = nameField.getText();
                long accountNumber = Long.parseLong(accountNumberField.getText());
                String bankDetails = bankDetailsField.getText();

                Beneficiary beneficiary = new Beneficiary(0, customerId, name, accountNumber, bankDetails);
                beneficiaryDAO.addBeneficiary(beneficiary);

                JOptionPane.showMessageDialog(null, "Beneficiary Added Successfully!");
            }
        });

        add(addButton);
        setVisible(true);
    }
}
