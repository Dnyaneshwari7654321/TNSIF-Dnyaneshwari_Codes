package models;

public class TransactionAccount {
}
